# Automated Resume Screening System
Modular ML project for resume classification and JD matching.