import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd
import joblib
import os
from sklearn.metrics.pairwise import cosine_similarity

from src.data_loader import load_data
from src.model_training import train_models
from src.prediction import predict_category
from src.matching import calculate_match_score


# ======================================================
# LOAD MODELS (TRAIN ONCE, LOAD FOREVER)
# ======================================================
@st.cache_resource
def load_models():
    """
    Loads models from disk if they exist.
    If not, trains models once and saves them.
    """

    model_dir = "models"

    # If models already exist → LOAD
    if os.path.exists(os.path.join(model_dir, "improved_model.pkl")):
        basic_model = joblib.load(os.path.join(model_dir, "basic_model.pkl"))
        adv_model = joblib.load(os.path.join(model_dir, "improved_model.pkl"))
        tfidf_basic = joblib.load(os.path.join(model_dir, "tfidf_basic.pkl"))
        tfidf_adv = joblib.load(os.path.join(model_dir, "tfidf_adv.pkl"))

        # Load data only for ranking
        df = load_data("data/resume_data.csv")

        # Accuracy already known from training phase
        acc_basic = 0.0
        acc_adv = 0.0

        return basic_model, adv_model, tfidf_basic, tfidf_adv, acc_basic, acc_adv, df

    # ELSE → TRAIN MODELS ONCE
    df = load_data("data/resume_data.csv")
    basic_model, adv_model, tfidf_basic, tfidf_adv, acc_basic, acc_adv = train_models(df)

    return basic_model, adv_model, tfidf_basic, tfidf_adv, acc_basic, acc_adv, df


# Load everything
basic_model, adv_model, tfidf_basic, tfidf_adv, acc_basic, acc_adv, df = load_models()


# ======================================================
# APP UI
# ======================================================
st.title("📄 Automated Resume Screening System")


# ======================================================
# MODEL ACCURACY (TEXT)
# ======================================================
st.subheader("📊 Model Accuracy Comparison")

if acc_basic > 0 and acc_adv > 0:
    st.write(f"🔸 Naive Bayes Accuracy (Before): **{acc_basic*100:.2f}%**")
    st.write(f"🔹 Logistic Regression Accuracy (After): **{acc_adv*100:.2f}%**")
else:
    st.info("✅ Pre-trained models loaded from disk (no retraining performed).")


# ======================================================
# RESUME CATEGORY PREDICTION
# ======================================================
st.subheader("🧠 Resume Category Prediction")

resume_text_pred = st.text_area(
    "Paste Resume Text for Category Prediction",
    key="resume_prediction"
)

if st.button("Predict Category"):
    if resume_text_pred.strip():
        prediction = predict_category(
            resume_text_pred,
            adv_model,
            tfidf_adv
        )
        st.success(f"✅ Predicted Category: **{prediction}**")
    else:
        st.warning("Please paste resume text.")


# ======================================================
# RESUME–JOB DESCRIPTION MATCHING SCORE
# ======================================================
st.subheader("🔗 Resume & Job Description Matching Score")

resume_text_match = st.text_area(
    "Paste Resume Text for Matching",
    key="resume_matching"
)

job_desc_match = st.text_area(
    "Paste Job Description for Matching",
    key="jd_matching"
)

if st.button("Calculate Matching Score"):
    if resume_text_match.strip() and job_desc_match.strip():
        score = calculate_match_score(
            resume_text_match,
            job_desc_match,
            tfidf_adv
        )

        st.success(f"✅ Matching Score: **{score}%**")

        if score >= 80:
            st.write("🟢 Excellent Match")
        elif score >= 60:
            st.write("🟡 Good Match")
        else:
            st.write("🔴 Low Match")
    else:
        st.warning("Please enter both resume and job description.")


# ======================================================
# RESUME RANKING BASED ON JOB DESCRIPTION
# ======================================================
st.subheader("🏆 Resume Ranking Based on Job Description")

job_desc_rank = st.text_area(
    "Enter Job Description for Ranking",
    key="jd_ranking"
)

if st.button("Rank Resumes"):
    if job_desc_rank.strip():
        job_desc_clean = job_desc_rank.lower()

        # ✅ Extract required columns
        resumes = df["Clean_Resume"].tolist()
        categories = df["Category"].tolist()
        resume_ids = df["ID"].tolist()   # ✅ ADD THIS

        # Vectorize
        documents = [job_desc_clean] + resumes
        vectors = tfidf_adv.transform(documents)

        similarity_scores = cosine_similarity(
            vectors[0:1], vectors[1:]
        )[0]

        # ✅ Create ranking DataFrame WITH ID
        ranking_df = pd.DataFrame({
            "Resume ID": resume_ids,
            "Category": categories,
            "Match Score (%)": (similarity_scores * 100).round(2)
        })

        # Sort and rank
        ranking_df = ranking_df.sort_values(
            by="Match Score (%)",
            ascending=False
        ).reset_index(drop=True)

        ranking_df["Rank"] = ranking_df.index + 1

        # Display top results
        st.dataframe(ranking_df.head(10))

    else:
        st.warning("Please enter a job description.")