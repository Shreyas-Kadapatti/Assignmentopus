from sklearn.metrics.pairwise import cosine_similarity
from src.text_preprocessing import clean_text

def calculate_match_score(resume, job_desc, tfidf):
    r = clean_text(resume)
    j = clean_text(job_desc)
    sim = cosine_similarity(tfidf.transform([j]), tfidf.transform([r]))[0][0]
    return round(sim * 100, 2)

