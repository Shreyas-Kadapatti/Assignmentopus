import pandas as pd
import os
from src.text_preprocessing import clean_text


def load_data(path):
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    full_path = os.path.join(base_dir, path)

    if not os.path.exists(full_path):
        raise FileNotFoundError(f"Dataset not found at: {full_path}")

    df = pd.read_csv(full_path)

    # ✅ KEEP ID COLUMN
    df = df[['ID', 'Resume_str', 'Category']].dropna()

    # Clean resume text
    df['Clean_Resume'] = df['Resume_str'].apply(clean_text)

    # Remove very short resumes
    df = df[df['Clean_Resume'].str.len() > 100]

    return df