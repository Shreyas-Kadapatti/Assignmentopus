from src.text_preprocessing import clean_text

def predict_category(text, model, tfidf):
    text = clean_text(text)
    return model.predict(tfidf.transform([text]))[0]
