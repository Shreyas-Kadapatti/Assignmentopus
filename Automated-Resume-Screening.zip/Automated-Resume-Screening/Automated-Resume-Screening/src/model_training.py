import os
import joblib

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score


def train_models(df):
    """
    Trains two models:
    1. Naive Bayes (Baseline - Before Improvement)
    2. Logistic Regression (Improved Model)

    Saves trained models and TF-IDF vectorizers to disk.
    """

    # Target variable
    y = df["Category"]

    # ==================================================
    # BEFORE MODEL: Naive Bayes
    # ==================================================
    tfidf_basic = TfidfVectorizer(stop_words="english")
    X_basic = tfidf_basic.fit_transform(df["Clean_Resume"])

    Xb_train, Xb_test, yb_train, yb_test = train_test_split(
        X_basic, y, test_size=0.2, random_state=42
    )

    basic_model = MultinomialNB()
    basic_model.fit(Xb_train, yb_train)

    acc_basic = accuracy_score(
        yb_test, basic_model.predict(Xb_test)
    )

    # ==================================================
    # AFTER MODEL: Logistic Regression (Improved)
    # ==================================================
    tfidf_adv = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        max_features=5000
    )

    X_adv = tfidf_adv.fit_transform(df["Clean_Resume"])

    Xa_train, Xa_test, ya_train, ya_test = train_test_split(
        X_adv, y, test_size=0.2, random_state=42, stratify=y
    )

    adv_model = LogisticRegression(
        max_iter=1000,
        class_weight="balanced"
    )
    adv_model.fit(Xa_train, ya_train)

    acc_adv = accuracy_score(
        ya_test, adv_model.predict(Xa_test)
    )

    # ==================================================
    # SAVE MODELS TO DISK (.pkl)
    # ==================================================
    os.makedirs("models", exist_ok=True)

    joblib.dump(basic_model, "models/basic_model.pkl")
    joblib.dump(adv_model, "models/improved_model.pkl")
    joblib.dump(tfidf_basic, "models/tfidf_basic.pkl")
    joblib.dump(tfidf_adv, "models/tfidf_adv.pkl")

    # ==================================================
    # RETURN EVERYTHING
    # ==================================================
    return (
        basic_model,
        adv_model,
        tfidf_basic,
        tfidf_adv,
        acc_basic,
        acc_adv
    )